This is the PSOImageEditor Project for Rhythmyx 6.x  

The image editor allows for uploading, cropping, resizing and storing of multiple
    sizes of a single image. 

THIS VERSION REQUIRES RHYTHMYX 6.5.2 OR LATER 


To deploy the toolkit, unzip the distribution into an empty directory. 

You must have Java 1.5 and Apache Ant properly installed. 

The RHYTHMYX_HOME environment variable must point at your 
Rhythmyx 6.5 installation.  

Type the command: 

ant -f deploy.xml 

